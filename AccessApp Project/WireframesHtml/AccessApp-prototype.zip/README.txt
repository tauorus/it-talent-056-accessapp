Important Notice:

You have successfully downloaded your pidoco project from our web server.
Well done! But before starting your offline work, you first need to 
unzip/extract the files.

Windows Users:
Right click on the zip file to extract it and choose a location for your files.
Then go to the location of the extracted files and start working with them.

A few additional hints:
Open the index.html with your browser and choose a page in either sketched or plain mode.

If you plan to deploy the files on your own web server, please make sure 
that the xhtml files are being published with mime type "application/xhtml+xml".

The Pidoco team