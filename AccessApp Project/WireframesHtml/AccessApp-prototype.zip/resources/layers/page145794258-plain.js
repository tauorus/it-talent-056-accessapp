rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page145794258-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page145794258" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page145794258-layer-text461180741" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text461180741" data-review-reference-id="text461180741">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-textinput146036319" style="position: absolute; left: 15px; top: 240px; width: 325px; height: 35px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput146036319" data-review-reference-id="textinput146036319">\
            <div class="stencil-wrapper" style="width: 325px; height: 35px">\
               <div title="Usuario"><textarea id="__containerId__-page145794258-layer-textinput146036319input" rows="" cols="" style="width:323px;height:31px;padding: 0px;border-width:1px;">Correo Electrónico</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-textinput169963644" style="position: absolute; left: 15px; top: 290px; width: 325px; height: 35px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput169963644" data-review-reference-id="textinput169963644">\
            <div class="stencil-wrapper" style="width: 325px; height: 35px">\
               <div title="Password"><textarea id="__containerId__-page145794258-layer-textinput169963644input" rows="" cols="" style="width:323px;height:31px;padding: 0px;border-width:1px;">Contraseña</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-iphoneButton268812010" style="position: absolute; left: 245px; top: 560px; width: 78px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton268812010" data-review-reference-id="iphoneButton268812010">\
            <div class="stencil-wrapper" style="width: 78px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:78px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="78" height="30" viewBox="0 0 78 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 60,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                        <svg:text x="36" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Ingresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 78px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page145794258-layer-iphoneButton268812010\', \'interaction733630436\', {"button":"left","id":"action388591144","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction149926959","options":"reloadOnly","target":"page129521174","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page145794258-layer-iphoneButton54687354" style="position: absolute; left: 30px; top: 560px; width: 80px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton54687354" data-review-reference-id="iphoneButton54687354">\
            <div class="stencil-wrapper" style="width: 80px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:80px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="80" height="30" viewBox="0 0 80 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M13,29.5 l-0.5,-0.5 -1,0 -1,-1 -1.5,-1.5 -8.5,-11 7.5,-11 2,-2.5 1.5,-1 0.5,-0.5 62,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="43" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Salir</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-text515825532" style="position: absolute; left: 30px; top: 155px; width: 284px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text515825532" data-review-reference-id="text515825532">\
            <div class="stencil-wrapper" style="width: 284px; height: 17px">\
               <div title="" style="width:289px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Por favor ingrese sus datos para acceder.</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-text931270129" style="position: absolute; left: 130px; top: 375px; width: 78px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text931270129" data-review-reference-id="text931270129">\
            <div class="stencil-wrapper" style="width: 78px; height: 17px">\
               <div title="Registro" style="width:83px"><span class="default-text2-container-wrapper" title="Registro"><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Registrarse</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 78px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page145794258-layer-text931270129\', \'interaction78725298\', {"button":"left","id":"action313100823","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction439613120","options":"reloadOnly","target":"page865177353","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page145794258-layer-icon383850843" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="icon383850843" data-review-reference-id="icon383850843">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-608598058" style="position: absolute; left: 20px; top: 45px; width: 43px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="608598058" data-review-reference-id="608598058">\
            <div class="stencil-wrapper" style="width: 43px; height: 17px">\
               <div title="" style="width:48px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Inicio </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-691160920" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="691160920" data-review-reference-id="691160920">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page145794258-layer-text992081355" style="position: absolute; left: 105px; top: 425px; width: 149px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text992081355" data-review-reference-id="text992081355">\
            <div class="stencil-wrapper" style="width: 149px; height: 17px">\
               <div title="" style="width:154px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Olvidó su contraseña ?</p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 149px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page145794258-layer-text992081355\', \'interaction773187035\', {"button":"left","id":"action700068854","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction151945262","text":"Se envió la nueva contraseña al correo electrónico indicado.","title":"DiscApp Ruta Olvidó su contraseña","type":"systemAlert"}\
					]\
				);\
			});\
		</script></div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page145794258"] .border-wrapper, body[data-current-page-id="page145794258"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page145794258"] .border-wrapper, body.has-frame[data-current-page-id="page145794258"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page145794258"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page145794258"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page145794258",\
      			"name": "0. AccessApp Home",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
</div>');