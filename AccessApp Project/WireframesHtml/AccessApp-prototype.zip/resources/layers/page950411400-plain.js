rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page950411400-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page950411400" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page950411400-layer-1429181801" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1429181801" data-review-reference-id="1429181801">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page950411400-layer-1299119142" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1299119142" data-review-reference-id="1299119142">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page950411400-layer-1489898984" style="position: absolute; left: 20px; top: 45px; width: 46px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1489898984" data-review-reference-id="1489898984">\
            <div class="stencil-wrapper" style="width: 46px; height: 17px">\
               <div title="" style="width:51px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Rutas</span> </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page950411400-layer-text60441790" style="position: absolute; left: 40px; top: 205px; width: 216px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="text60441790" data-review-reference-id="text60441790">\
            <div class="stencil-wrapper" style="width: 216px; height: 17px">\
               <div title="" style="width:221px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Ruta 1: Calle 3 hasta Av. Jimenez</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 216px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page950411400-layer-text60441790\', \'interaction28298623\', {"button":"left","id":"action417391951","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction818218548","options":"reloadOnly","target":"page139247244","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page950411400-layer-502192336" style="position: absolute; left: 40px; top: 240px; width: 240px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="502192336" data-review-reference-id="502192336">\
            <div class="stencil-wrapper" style="width: 240px; height: 17px">\
               <div title="" style="width:245px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Ruta 2: Candelaria hasta Av. Jimenez</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 240px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page950411400-layer-502192336\', \'interaction642637474\', {"button":"left","id":"action202328199","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction51414548","options":"reloadOnly","target":"page139247244","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page950411400-layer-1489569830" style="position: absolute; left: 40px; top: 275px; width: 264px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1489569830" data-review-reference-id="1489569830">\
            <div class="stencil-wrapper" style="width: 264px; height: 17px">\
               <div title="" style="width:269px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.link2"><p style="font-size: 14px;"><span class="underline">Ruta 3: Torre Colpatria a Plaza de Bolivar</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 264px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page950411400-layer-1489569830\', \'interaction295944274\', {"button":"left","id":"action736400051","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction127448354","options":"reloadOnly","target":"page139247244","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page950411400-layer-iphoneButton494785786" style="position: absolute; left: 130px; top: 495px; width: 69px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton494785786" data-review-reference-id="iphoneButton494785786">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:69px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="69" height="30" viewBox="0 0 69 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M13,29.5 l-0.5,-0.5 -1,0 -1,-1 -1.5,-1.5 -8.5,-11 7.5,-11 2,-2.5 1.5,-1 0.5,-0.5 51,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="37.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Regresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page950411400-layer-iphoneButton494785786\', \'interaction798589600\', {"button":"left","id":"action467805859","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction365505615","options":"reloadOnly","target":"page129521174","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page950411400-layer-1047734080" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1047734080" data-review-reference-id="1047734080">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page950411400-layer-1660315860" style="position: absolute; left: 40px; top: 105px; width: 193px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1660315860" data-review-reference-id="1660315860">\
            <div class="stencil-wrapper" style="width: 193px; height: 17px">\
               <div title="" style="width:198px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Listado de Rutas Existentes</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page950411400-layer-1379609380" style="position: absolute; left: 40px; top: 135px; width: 244px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1379609380" data-review-reference-id="1379609380">\
            <div class="stencil-wrapper" style="width: 244px; height: 17px">\
               <div title="" style="width:249px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Seleccione una ruta para mas detalles</span></p></span></span></div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page950411400"] .border-wrapper, body[data-current-page-id="page950411400"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page950411400"] .border-wrapper, body.has-frame[data-current-page-id="page950411400"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page950411400"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page950411400"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page950411400",\
      			"name": "3. AccessApp Consulta Rutas",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
</div>');