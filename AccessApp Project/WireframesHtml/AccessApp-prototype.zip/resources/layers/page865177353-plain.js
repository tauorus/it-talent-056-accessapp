rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page865177353-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page865177353" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page865177353-layer-2082194275" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2082194275" data-review-reference-id="2082194275">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-212843526" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="212843526" data-review-reference-id="212843526">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-677103356" style="position: absolute; left: 20px; top: 45px; width: 62px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="677103356" data-review-reference-id="677103356">\
            <div class="stencil-wrapper" style="width: 62px; height: 17px">\
               <div title="" style="width:67px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Registro </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-textinput319711027" style="position: absolute; left: 25px; top: 180px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput319711027" data-review-reference-id="textinput319711027">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-textinput319711027input" value="Correo Electrónico" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-809139677" style="position: absolute; left: 25px; top: 230px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="809139677" data-review-reference-id="809139677">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-809139677input" value="Contraseña" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-1840084562" style="position: absolute; left: 25px; top: 330px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1840084562" data-review-reference-id="1840084562">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-1840084562input" value="Nombres" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-355627079" style="position: absolute; left: 25px; top: 380px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="355627079" data-review-reference-id="355627079">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-355627079input" value="Apellidos" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-iphoneButton378895324" style="position: absolute; left: 245px; top: 570px; width: 85px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton378895324" data-review-reference-id="iphoneButton378895324">\
            <div class="stencil-wrapper" style="width: 85px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:85px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="85" height="30" viewBox="0 0 85 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 67,0 0.5,0.5 1,0 1,1 1.5,1.5 8.5,11 -7.5,11 -2,2.5 -1.5,1 -0.5,0.5 z"></svg:path>\
                        <svg:text x="39.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Registrarme</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 85px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page865177353-layer-iphoneButton378895324\', \'interaction325329308\', {"button":"left","id":"action36893534","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction278019732","options":"reloadOnly","target":"page145794258","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page865177353-layer-iphoneButton378895324\', \'interaction480867223\', {"button":"left","id":"action614724160","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction917304065","text":"Registro Correcto, ahora puede ingresar con su correo electrónico y contraseña.","title":"Registro","type":"systemAlert"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page865177353-layer-2058947948" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="2058947948" data-review-reference-id="2058947948">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-iphoneButton692390712" style="position: absolute; left: 20px; top: 570px; width: 88px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton692390712" data-review-reference-id="iphoneButton692390712">\
            <div class="stencil-wrapper" style="width: 88px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:88px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="88" height="30" viewBox="0 0 88 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M13,29.5 l-0.5,-0.5 -1,0 -1,-1 -1.5,-1.5 -8.5,-11 7.5,-11 2,-2.5 1.5,-1 0.5,-0.5 70,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="47" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Regresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 88px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page865177353-layer-iphoneButton692390712\', \'interaction344163885\', {"button":"left","id":"action317021150","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction838196975","options":"reloadOnly","target":"page145794258","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page865177353-layer-1484198700" style="position: absolute; left: 25px; top: 280px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1484198700" data-review-reference-id="1484198700">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-1484198700input" value="Verifique Contraseña" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-169169858" style="position: absolute; left: 25px; top: 430px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="169169858" data-review-reference-id="169169858">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-169169858input" value="Teléfono" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-1491094365" style="position: absolute; left: 25px; top: 480px; width: 310px; height: 30px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="1491094365" data-review-reference-id="1491094365">\
            <div class="stencil-wrapper" style="width: 310px; height: 30px">\
               <div title=""><input id="__containerId__-page865177353-layer-1491094365input" value="Dirección" style="width:308px;height:28px;padding: 0px;border-width:1px;" type="text" /></div>\
            </div>\
         </div>\
         <div id="__containerId__-page865177353-layer-703115088" style="position: absolute; left: 25px; top: 110px; width: 306px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="703115088" data-review-reference-id="703115088">\
            <div class="stencil-wrapper" style="width: 306px; height: 17px">\
               <div title="" style="width:311px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Por favor ingrese su información de registro.</span></p></span></span></div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page865177353"] .border-wrapper, body[data-current-page-id="page865177353"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page865177353"] .border-wrapper, body.has-frame[data-current-page-id="page865177353"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page865177353"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page865177353"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page865177353",\
      			"name": "1. AccessApp Registro",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
</div>');