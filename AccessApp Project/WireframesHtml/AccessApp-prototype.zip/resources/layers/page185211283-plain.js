rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page185211283-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page185211283" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page185211283-layer-clickArea524542995" style="position: absolute; left: 20px; top: 150px; width: 310px; height: 390px" data-interactive-element-type="default.clickArea" class="clickArea stencil mobile-interaction-potential-trigger " data-stencil-id="clickArea524542995" data-review-reference-id="clickArea524542995">\
            <div class="stencil-wrapper" style="width: 310px; height: 390px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 390px; width:310px; cursor:pointer;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" data-stencil="ClickArea" overflow="hidden" style="height: 390px;width:310px;" width="310" height="390" viewBox="0 0 310 390">\
                     <svg:a>\
                        <svg:rect x="0" y="0" width="310" height="390" style="stroke:none;fill:white;opacity:0.01;"></svg:rect>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-image94775119" style="position: absolute; left: 35px; top: 355px; width: 281px; height: 145px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image94775119" data-review-reference-id="image94775119">\
            <div class="stencil-wrapper" style="width: 281px; height: 145px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 145px;width:281px;" width="281" height="145" viewBox="0 0 281 145">\
                     <svg:g width="281" height="145">\
                        <svg:svg x="0" y="0" width="281" height="145">\
                           <svg:image width="728" height="410" xlink:href="../repoimages/687852.png" preserveAspectRatio="none" transform="scale(0.385989010989011,0.35365853658536583) translate(-0,-0)  "></svg:image>\
                        </svg:svg>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-textinput734822200" style="position: absolute; left: 180px; top: 215px; width: 135px; height: 135px" data-interactive-element-type="default.textinput" class="textinput stencil mobile-interaction-potential-trigger " data-stencil-id="textinput734822200" data-review-reference-id="textinput734822200">\
            <div class="stencil-wrapper" style="width: 135px; height: 135px">\
               <div title=""><textarea id="__containerId__-page185211283-layer-textinput734822200input" rows="" cols="" style="width:133px;height:131px;padding: 0px;border-width:1px;">Descripción</textarea></div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-1598571433" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1598571433" data-review-reference-id="1598571433">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-1761310391" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="1761310391" data-review-reference-id="1761310391">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-114496619" style="position: absolute; left: 20px; top: 45px; width: 123px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="114496619" data-review-reference-id="114496619">\
            <div class="stencil-wrapper" style="width: 123px; height: 17px">\
               <div title="" style="width:128px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Crear Nueva Ruta </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-iphoneButton143371391" style="position: absolute; left: 105px; top: 105px; width: 132px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton143371391" data-review-reference-id="iphoneButton143371391">\
            <div class="stencil-wrapper" style="width: 132px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:132px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="132" height="30" viewBox="0 0 132 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 122,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="66" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Iniciar nueva Ruta</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 132px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-iphoneButton143371391\', \'interaction377628624\', {"button":"left","id":"action124352842","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction700432872","text":"Ubicación por gps activa. Creación de Ruta Iniciada.","title":"DiscApp Ruta","type":"systemAlert"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page185211283-layer-text605160120" style="position: absolute; left: 120px; top: 155px; width: 116px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="text605160120" data-review-reference-id="text605160120">\
            <div class="stencil-wrapper" style="width: 116px; height: 17px">\
               <div title="" style="width:121px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;">Ruta No: CA1234</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-image785658717" style="position: absolute; left: 35px; top: 215px; width: 135px; height: 135px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image785658717" data-review-reference-id="image785658717">\
            <div class="stencil-wrapper" style="width: 135px; height: 135px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 135px;width:135px;" width="135" height="135" viewBox="0 0 135 135">\
                     <svg:g width="135" height="135">\
                        <svg:rect x="0" y="0" width="135" height="135" style="stroke:black; stroke-width:1;fill:white;"></svg:rect>\
                        <svg:line x1="0" y1="0" x2="135" y2="135" style="stroke:black; stroke-width:0.5;"></svg:line>\
                        <svg:line x1="0" y1="135" x2="135" y2="0" style="stroke:black; stroke-width:0.5;"></svg:line>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-iphoneButton385250975" style="position: absolute; left: 105px; top: 505px; width: 135px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton385250975" data-review-reference-id="iphoneButton385250975">\
            <div class="stencil-wrapper" style="width: 135px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:135px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="135" height="30" viewBox="0 0 135 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 125,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="67.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Grabar Punto Ruta</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 135px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-iphoneButton385250975\', \'interaction512860959\', {"button":"left","id":"action626799838","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction54342006","text":"Punto de Ruta se grabó en la base de datos.","title":"DiscApp Ruta","type":"systemAlert"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page185211283-layer-iphoneButton425684347" style="position: absolute; left: 90px; top: 555px; width: 165px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton425684347" data-review-reference-id="iphoneButton425684347">\
            <div class="stencil-wrapper" style="width: 165px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:165px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="165" height="30" viewBox="0 0 165 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 155,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="82.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Finalizar nueva Ruta</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 165px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-iphoneButton425684347\', \'interaction473236014\', {"button":"left","id":"action430915703","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction725722935","text":"Creación de Ruta Finalizada","title":"DiscApp Ruta","type":"systemAlert"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page185211283-layer-iphoneButton765606635" style="position: absolute; left: 90px; top: 175px; width: 163px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton765606635" data-review-reference-id="iphoneButton765606635">\
            <div class="stencil-wrapper" style="width: 163px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:163px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="163" height="30" viewBox="0 0 163 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M5,29.5 l-2,-0.5 -1,-1 -1,-1.5 -0.5,-1.5 0,-20 0.5,-2 1,-1 1,-1 2,-0.5 153,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="81.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Cargar Imagen Punto Ruta</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 163px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-iphoneButton765606635\', \'interaction193492284\', {"button":"left","id":"action499821090","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction631875596","options":"reloadOnly","target":"page479595724","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page185211283-layer-iphoneButton88588281" style="position: absolute; left: 145px; top: 600px; width: 69px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton88588281" data-review-reference-id="iphoneButton88588281">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:69px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="69" height="30" viewBox="0 0 69 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M13,29.5 l-0.5,-0.5 -1,0 -1,-1 -1.5,-1.5 -8.5,-11 7.5,-11 2,-2.5 1.5,-1 0.5,-0.5 51,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="37.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Regresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-iphoneButton88588281\', \'interaction359192569\', {"button":"left","id":"action804961637","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction474077583","options":"reloadOnly","target":"page129521174","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page185211283-layer-arrow757945278" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="arrow757945278" data-review-reference-id="arrow757945278">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page185211283-layer-804517601" style="position: absolute; left: 150px; top: 75px; width: 48px; height: 17px" data-interactive-element-type="default.text2" class="text2 pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="804517601" data-review-reference-id="804517601">\
            <div class="stencil-wrapper" style="width: 48px; height: 17px">\
               <div title="" style="width:53px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Ayuda</span></p></span></span></div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 48px; height: 17px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page185211283-layer-804517601\', \'interaction504948682\', {"button":"left","id":"action971969626","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction242313657","options":"reloadOnly","target":"page296741346","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page185211283"] .border-wrapper, body[data-current-page-id="page185211283"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page185211283"] .border-wrapper, body.has-frame[data-current-page-id="page185211283"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page185211283"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page185211283"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page185211283",\
      			"name": "4.1 AccessApp Crear Nueva Ruta",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
</div>');