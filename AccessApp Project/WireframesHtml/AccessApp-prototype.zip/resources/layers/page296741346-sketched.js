rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page296741346-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page296741346" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page296741346-layer-2142189676" style="position: absolute; left: 20px; top: 155px; width: 315px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2142189676" data-review-reference-id="2142189676">\
            <div class="stencil-wrapper" style="width: 315px; height: 32px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px; text-align: justify;">Recuerde activar la ubicación por GPS de su telèfono celular.</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-923755985" style="position: absolute; left: 20px; top: 210px; width: 315px; height: 178px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="923755985" data-review-reference-id="923755985">\
            <div class="stencil-wrapper" style="width: 315px; height: 178px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px; text-align: justify;">Para crear una nueva ruta se debe subir una foto, la cual será\
                        grabada y se incluirá su ubicación geográfica. <br /><br />Por favor ingrese una descripción del lugar de la foto por ejemplo,\
                        tiene rampla, es una subida o bajada, etc., también indicar la dirección exacta o aproximada si se tiene, incluir cuidados\
                        o advertencias que puedan servir y agregar información adicional que permita describir mejor la ruta para el discapacitado.</p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-337695253" style="position: absolute; left: 20px; top: 420px; width: 315px; height: 82px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="337695253" data-review-reference-id="337695253">\
            <div class="stencil-wrapper" style="width: 315px; height: 82px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px; text-align: justify;">Se debe hacer clic en el botón iniciar, empezar a subir las\
                        fotos, éstas se irán guardando en la base de datos al dar clic en grabar y hacer en clic en Finalizar para terminar de grabar\
                        los puntos de la ruta. </p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-1560578241" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1560578241" data-review-reference-id="1560578241">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-920777366" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="920777366" data-review-reference-id="920777366">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-1756324038" style="position: absolute; left: 20px; top: 45px; width: 123px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1756324038" data-review-reference-id="1756324038">\
            <div class="stencil-wrapper" style="width: 123px; height: 17px">\
               <div title="" style="width:128px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Crear Nueva Ruta </span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-1493445689" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1493445689" data-review-reference-id="1493445689">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4"><svg:path class=" svg_unselected_element" d="M 0.00, 2.00 Q 10.03, 2.43, 20.06, 1.84 Q 30.09, 2.24, 40.12, 1.04 Q 50.16, 1.66,\
                     60.19, 1.86 Q 70.22, 1.88, 80.25, 1.04 Q 90.28, 0.83, 100.31, 0.95 Q 110.34, 0.94, 120.38, 0.45 Q 130.41, 0.13, 140.44, 0.94\
                     Q 150.47, 0.95, 160.50, 1.57 Q 170.53, 1.37, 180.56, 1.39 Q 190.59, 1.84, 200.62, 0.26 Q 210.66, -0.25, 220.69, -0.28 Q 230.72,\
                     -0.42, 240.75, -0.22 Q 250.78, 0.35, 260.81, 0.11 Q 270.84, 0.47, 280.88, 0.70 Q 290.91, 0.28, 300.94, 0.19 Q 310.97, 2.00,\
                     321.00, 2.00" style="marker-start:;marker-end:"/>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page296741346-layer-iphoneButton327175386" style="position: absolute; left: 235px; top: 560px; width: 72px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton327175386" data-review-reference-id="iphoneButton327175386">\
            <div class="stencil-wrapper" style="width: 72px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:76px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="76" height="34" viewBox="-2 -2 76 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 4.00, 29.00 Q 1.69, 30.31, 0.87, 28.88 Q 0.86, 15.41, 1.19, 1.41 Q 2.18, 0.66,\
                        3.24, -0.48 Q 18.09, -0.89, 32.83, -0.69 Q 47.46, 0.21, 62.14, 0.33 Q 63.25, 0.78, 64.67, 1.13 Q 69.60, 7.47, 74.29, 14.93\
                        Q 69.83, 21.94, 65.02, 28.96 Q 63.81, 29.62, 62.32, 30.04 Q 47.63, 29.88, 33.07, 29.96 Q 18.50, 29.00, 4.00, 29.00" style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="33" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Continuar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 72px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page296741346-layer-iphoneButton327175386\', \'interaction314664717\', {"button":"left","id":"action359151216","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction530494155","options":"reloadOnly","target":"page185211283","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page296741346-layer-1607297450" style="position: absolute; left: 50px; top: 560px; width: 72px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="1607297450" data-review-reference-id="1607297450">\
            <div class="stencil-wrapper" style="width: 72px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="position: absolute; left: -2px; top: -2px;height: 34px;width:76px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="helvetica-font" width="76" height="34" viewBox="-2 -2 76 34">\
                     <svg:a><svg:path class=" svg_unselected_element" d="M 12.00, 29.00 Q 10.41, 29.67, 9.06, 29.08 Q 4.40, 22.49, 0.28, 15.04 Q 4.44,\
                        8.15, 9.19, 1.25 Q 10.56, 0.89, 11.88, 0.62 Q 26.37, 0.10, 40.93, -0.07 Q 55.47, -0.02, 70.20, 0.49 Q 70.71, 1.18, 70.78,\
                        2.11 Q 70.62, 15.08, 70.59, 27.87 Q 70.10, 28.24, 70.10, 29.20 Q 55.67, 29.78, 41.05, 29.48 Q 26.50, 29.00, 12.00, 29.00"\
                        style="fill-rule:evenodd;clip-rule:evenodd;fill:#808080;stroke:#666666;"/>\
                        <svg:text x="39" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Regresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 72px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page296741346-layer-1607297450\', \'interaction780783415\', {"button":"left","id":"action680070810","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction574298586","options":"reloadOnly","target":"page129521174","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page296741346-layer-1932017673" style="position: absolute; left: 20px; top: 110px; width: 305px; height: 18px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1932017673" data-review-reference-id="1932017673">\
            <div class="stencil-wrapper" style="width: 305px; height: 18px">\
               <div title="" style="width:310px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Para tener en cuenta al crear una nueva\
                        ruta:</span></p></span></span></div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page296741346"] .border-wrapper, body[data-current-page-id="page296741346"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page296741346"] .border-wrapper, body.has-frame[data-current-page-id="page296741346"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page296741346"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page296741346"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page296741346",\
      			"name": "4. AccessApp Help Crear Nueva Ruta",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
   <div id="border-wrapper">\
      <div xmlns="http://www.w3.org/1999/xhtml" xmlns:json="http://json.org/" class="svg-border svg-border-360-640" style="display: none;">\
         <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns="http://www.w3.org/2000/svg" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" class="svg_border" style="position:absolute;left:-43px;top:-13px;width:417px;height:664px;"><svg:path class=" svg_unselected_element" d="M 32.00, 3.00 Q 42.28, 3.12, 52.56, 3.05 Q 62.83, 2.90, 73.11, 3.04 Q 83.39,\
            3.67, 93.67, 3.00 Q 103.94, 3.41, 114.22, 2.32 Q 124.50, 2.73, 134.78, 2.47 Q 145.06, 2.04, 155.33, 1.86 Q 165.61, 2.32, 175.89,\
            2.58 Q 186.17, 2.07, 196.44, 1.03 Q 206.72, 0.88, 217.00, 1.58 Q 227.28, 2.72, 237.56, 1.81 Q 247.83, 1.15, 258.11, 1.36 Q\
            268.39, 1.37, 278.67, 1.23 Q 288.94, 1.11, 299.22, 1.27 Q 309.50, 1.45, 319.78, 1.29 Q 330.06, 1.17, 340.33, 1.05 Q 350.61,\
            1.32, 360.89, 1.09 Q 371.17, 0.98, 381.44, 0.92 Q 391.72, 1.47, 403.03, 1.97 Q 403.48, 12.59, 402.80, 23.04 Q 402.84, 33.18,\
            403.47, 43.27 Q 403.43, 53.37, 403.67, 63.46 Q 403.76, 73.54, 403.24, 83.62 Q 403.16, 93.70, 403.20, 103.78 Q 402.63, 113.86,\
            402.69, 123.94 Q 403.03, 134.02, 403.40, 144.09 Q 403.32, 154.17, 403.46, 164.25 Q 402.79, 174.33, 402.46, 184.41 Q 403.45,\
            194.48, 402.55, 204.56 Q 402.45, 214.64, 403.04, 224.72 Q 403.21, 234.80, 403.27, 244.88 Q 403.33, 254.95, 403.07, 265.03\
            Q 401.93, 275.11, 402.87, 285.19 Q 403.04, 295.27, 402.76, 305.34 Q 403.12, 315.42, 403.51, 325.50 Q 402.96, 335.58, 402.71,\
            345.66 Q 402.99, 355.73, 403.11, 365.81 Q 403.97, 375.89, 403.98, 385.97 Q 403.66, 396.05, 402.63, 406.12 Q 402.46, 416.20,\
            402.46, 426.28 Q 402.81, 436.36, 402.97, 446.44 Q 402.36, 456.52, 402.21, 466.59 Q 401.94, 476.67, 402.54, 486.75 Q 402.85,\
            496.83, 403.19, 506.91 Q 402.90, 516.98, 402.93, 527.06 Q 403.24, 537.14, 402.99, 547.22 Q 402.91, 557.30, 402.92, 567.38\
            Q 403.52, 577.45, 402.80, 587.53 Q 402.69, 597.61, 402.86, 607.69 Q 403.04, 617.77, 403.15, 627.84 Q 402.19, 637.92, 402.54,\
            648.54 Q 391.85, 648.38, 381.56, 648.84 Q 371.28, 649.63, 360.95, 649.84 Q 350.63, 649.28, 340.34, 648.44 Q 330.06, 648.56,\
            319.78, 647.65 Q 309.50, 648.60, 299.22, 649.43 Q 288.94, 648.62, 278.67, 648.30 Q 268.39, 648.06, 258.11, 647.76 Q 247.83,\
            647.88, 237.56, 648.68 Q 227.28, 648.25, 217.00, 648.83 Q 206.72, 649.04, 196.44, 649.14 Q 186.17, 649.46, 175.89, 649.08\
            Q 165.61, 649.32, 155.33, 648.60 Q 145.06, 647.95, 134.78, 646.93 Q 124.50, 647.85, 114.22, 648.02 Q 103.94, 648.01, 93.67,\
            647.62 Q 83.39, 647.05, 73.11, 647.43 Q 62.83, 647.67, 52.56, 648.09 Q 42.28, 648.58, 31.82, 648.18 Q 31.76, 638.00, 32.15,\
            627.82 Q 31.63, 617.79, 31.84, 607.69 Q 31.76, 597.61, 31.66, 587.53 Q 31.59, 577.45, 31.95, 567.38 Q 31.36, 557.30, 31.25,\
            547.22 Q 30.87, 537.14, 30.65, 527.06 Q 30.34, 516.98, 30.43, 506.91 Q 30.78, 496.83, 30.75, 486.75 Q 31.81, 476.67, 30.77,\
            466.59 Q 31.00, 456.52, 31.36, 446.44 Q 30.35, 436.36, 30.69, 426.28 Q 30.52, 416.20, 30.66, 406.12 Q 30.50, 396.05, 30.97,\
            385.97 Q 31.32, 375.89, 31.56, 365.81 Q 30.54, 355.73, 32.39, 345.66 Q 32.03, 335.58, 31.58, 325.50 Q 32.09, 315.42, 31.28,\
            305.34 Q 31.86, 295.27, 30.90, 285.19 Q 31.58, 275.11, 31.65, 265.03 Q 31.40, 254.95, 31.25, 244.88 Q 30.69, 234.80, 30.82,\
            224.72 Q 30.97, 214.64, 31.57, 204.56 Q 31.34, 194.48, 31.78, 184.41 Q 31.21, 174.33, 32.05, 164.25 Q 31.59, 154.17, 30.49,\
            144.09 Q 30.81, 134.02, 31.49, 123.94 Q 32.50, 113.86, 32.04, 103.78 Q 31.95, 93.70, 31.88, 83.62 Q 31.69, 73.55, 31.47, 63.47\
            Q 31.35, 53.39, 31.75, 43.31 Q 32.22, 33.23, 33.02, 23.16 Q 32.00, 13.08, 32.00, 3.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 23.00, 7.00 Q 33.28, 6.42, 43.56, 6.40 Q 53.83, 6.28, 64.11, 6.09 Q 74.39,\
            6.01, 84.67, 6.52 Q 94.94, 6.63, 105.22, 5.74 Q 115.50, 6.03, 125.78, 5.93 Q 136.06, 6.60, 146.33, 6.84 Q 156.61, 7.11, 166.89,\
            7.23 Q 177.17, 5.61, 187.44, 5.67 Q 197.72, 5.81, 208.00, 6.00 Q 218.28, 5.83, 228.56, 5.98 Q 238.83, 6.24, 249.11, 7.23 Q\
            259.39, 6.95, 269.67, 7.66 Q 279.94, 7.87, 290.22, 7.38 Q 300.50, 8.07, 310.78, 7.78 Q 321.06, 7.06, 331.33, 5.96 Q 341.61,\
            4.98, 351.89, 5.26 Q 362.17, 5.68, 372.44, 6.02 Q 382.72, 5.75, 393.38, 6.62 Q 393.45, 16.93, 393.97, 27.02 Q 393.27, 37.22,\
            393.91, 47.28 Q 393.60, 57.38, 393.13, 67.47 Q 392.61, 77.55, 392.59, 87.63 Q 391.74, 97.70, 393.37, 107.78 Q 393.90, 117.86,\
            393.10, 127.94 Q 392.45, 138.02, 393.38, 148.09 Q 393.48, 158.17, 394.49, 168.25 Q 393.33, 178.33, 393.49, 188.41 Q 393.52,\
            198.48, 393.53, 208.56 Q 392.75, 218.64, 392.87, 228.72 Q 393.14, 238.80, 393.36, 248.88 Q 394.04, 258.95, 394.51, 269.03\
            Q 394.28, 279.11, 394.68, 289.19 Q 395.02, 299.27, 394.84, 309.34 Q 395.26, 319.42, 394.35, 329.50 Q 394.98, 339.58, 394.97,\
            349.66 Q 394.77, 359.73, 394.34, 369.81 Q 393.59, 379.89, 393.74, 389.97 Q 394.48, 400.05, 394.52, 410.12 Q 393.62, 420.20,\
            392.85, 430.28 Q 393.46, 440.36, 393.86, 450.44 Q 394.07, 460.52, 393.59, 470.59 Q 393.85, 480.67, 393.40, 490.75 Q 392.89,\
            500.83, 393.25, 510.91 Q 394.06, 520.98, 393.59, 531.06 Q 393.09, 541.14, 392.30, 551.22 Q 393.83, 561.30, 394.38, 571.38\
            Q 394.21, 581.45, 394.86, 591.53 Q 394.12, 601.61, 393.43, 611.69 Q 393.08, 621.77, 392.36, 631.84 Q 391.39, 641.92, 393.14,\
            652.14 Q 382.97, 652.74, 372.48, 652.27 Q 362.27, 653.55, 351.94, 653.64 Q 341.63, 653.09, 331.33, 652.02 Q 321.06, 652.15,\
            310.78, 652.84 Q 300.50, 652.83, 290.22, 653.04 Q 279.94, 653.56, 269.67, 653.56 Q 259.39, 653.14, 249.11, 652.19 Q 238.83,\
            651.90, 228.56, 651.29 Q 218.28, 651.26, 208.00, 651.47 Q 197.72, 651.72, 187.44, 651.65 Q 177.17, 651.97, 166.89, 652.35\
            Q 156.61, 652.27, 146.33, 652.81 Q 136.06, 653.12, 125.78, 652.60 Q 115.50, 653.43, 105.22, 653.72 Q 94.94, 653.72, 84.67,\
            653.53 Q 74.39, 653.17, 64.11, 652.88 Q 53.83, 653.51, 43.56, 654.13 Q 33.28, 653.37, 22.47, 652.53 Q 21.94, 642.28, 22.00,\
            631.99 Q 21.26, 621.88, 21.23, 611.74 Q 21.41, 601.63, 21.36, 591.54 Q 21.10, 581.46, 21.82, 571.38 Q 22.06, 561.30, 22.57,\
            551.22 Q 22.83, 541.14, 22.41, 531.06 Q 22.06, 520.98, 21.75, 510.91 Q 21.48, 500.83, 21.34, 490.75 Q 21.25, 480.67, 21.41,\
            470.59 Q 22.45, 460.52, 22.18, 450.44 Q 21.46, 440.36, 21.86, 430.28 Q 21.36, 420.20, 22.46, 410.12 Q 21.45, 400.05, 21.33,\
            389.97 Q 21.50, 379.89, 21.73, 369.81 Q 21.74, 359.73, 21.20, 349.66 Q 21.99, 339.58, 21.86, 329.50 Q 21.65, 319.42, 22.86,\
            309.34 Q 23.06, 299.27, 22.21, 289.19 Q 21.30, 279.11, 20.94, 269.03 Q 21.42, 258.95, 21.41, 248.88 Q 21.64, 238.80, 22.04,\
            228.72 Q 23.27, 218.64, 23.65, 208.56 Q 22.56, 198.48, 21.67, 188.41 Q 21.80, 178.33, 21.43, 168.25 Q 22.64, 158.17, 22.74,\
            148.09 Q 21.82, 138.02, 21.46, 127.94 Q 21.32, 117.86, 21.63, 107.78 Q 22.10, 97.70, 21.36, 87.62 Q 21.57, 77.55, 21.41, 67.47\
            Q 21.72, 57.39, 22.27, 47.31 Q 23.47, 37.23, 24.01, 27.16 Q 23.00, 17.08, 23.00, 7.00" style=" fill:white;"/><svg:path class=" svg_unselected_element" d="M 40.00, 11.00 Q 50.28, 9.09, 60.56, 8.84 Q 70.83, 9.42, 81.11, 9.27 Q 91.39,\
            10.51, 101.67, 10.20 Q 111.94, 10.89, 122.22, 9.80 Q 132.50, 9.64, 142.78, 11.38 Q 153.06, 10.75, 163.33, 10.68 Q 173.61,\
            11.33, 183.89, 11.73 Q 194.17, 11.32, 204.44, 9.45 Q 214.72, 8.64, 225.00, 9.71 Q 235.28, 10.29, 245.56, 10.87 Q 255.83, 10.23,\
            266.11, 9.90 Q 276.39, 10.14, 286.67, 9.74 Q 296.94, 10.56, 307.22, 10.28 Q 317.50, 10.56, 327.78, 10.54 Q 338.06, 10.77,\
            348.33, 10.32 Q 358.61, 8.83, 368.89, 8.68 Q 379.17, 8.66, 389.44, 8.54 Q 399.72, 8.47, 410.63, 10.37 Q 411.25, 20.66, 411.89,\
            30.89 Q 411.62, 41.13, 411.58, 51.26 Q 410.75, 61.38, 411.10, 71.46 Q 410.82, 81.54, 410.45, 91.62 Q 409.97, 101.70, 410.07,\
            111.78 Q 410.78, 121.86, 410.70, 131.94 Q 409.76, 142.02, 409.57, 152.09 Q 410.01, 162.17, 409.77, 172.25 Q 409.57, 182.33,\
            409.44, 192.41 Q 409.56, 202.48, 409.54, 212.56 Q 408.84, 222.64, 409.05, 232.72 Q 409.24, 242.80, 410.07, 252.88 Q 410.64,\
            262.95, 411.98, 273.03 Q 411.99, 283.11, 411.60, 293.19 Q 411.70, 303.27, 411.73, 313.34 Q 411.87, 323.42, 412.13, 333.50\
            Q 412.37, 343.58, 412.36, 353.66 Q 411.64, 363.73, 409.92, 373.81 Q 410.08, 383.89, 410.49, 393.97 Q 411.35, 404.05, 411.43,\
            414.12 Q 411.07, 424.20, 411.32, 434.28 Q 411.06, 444.36, 411.44, 454.44 Q 411.58, 464.52, 410.93, 474.59 Q 410.76, 484.67,\
            411.88, 494.75 Q 410.48, 504.83, 410.96, 514.91 Q 410.94, 524.98, 411.13, 535.06 Q 411.18, 545.14, 411.32, 555.22 Q 411.35,\
            565.30, 411.06, 575.38 Q 410.37, 585.45, 410.83, 595.53 Q 410.83, 605.61, 411.41, 615.69 Q 411.41, 625.77, 411.29, 635.84\
            Q 412.31, 645.92, 410.85, 656.85 Q 400.25, 657.58, 389.67, 657.58 Q 379.21, 656.65, 368.90, 656.49 Q 358.62, 656.61, 348.34,\
            656.64 Q 338.06, 656.68, 327.78, 656.56 Q 317.50, 656.44, 307.22, 656.58 Q 296.94, 656.68, 286.67, 656.76 Q 276.39, 656.59,\
            266.11, 656.30 Q 255.83, 657.00, 245.56, 656.87 Q 235.28, 657.58, 225.00, 656.91 Q 214.72, 656.61, 204.44, 657.32 Q 194.17,\
            656.73, 183.89, 656.84 Q 173.61, 657.18, 163.33, 657.67 Q 153.06, 656.70, 142.78, 657.27 Q 132.50, 656.70, 122.22, 656.58\
            Q 111.94, 656.82, 101.67, 656.47 Q 91.39, 656.61, 81.11, 656.68 Q 70.83, 657.33, 60.56, 657.03 Q 50.28, 658.02, 39.29, 656.71\
            Q 38.77, 646.33, 38.60, 636.04 Q 38.62, 625.86, 38.68, 615.73 Q 38.82, 605.63, 38.30, 595.54 Q 39.06, 585.46, 39.68, 575.38\
            Q 40.00, 565.30, 39.34, 555.22 Q 39.65, 545.14, 40.18, 535.06 Q 39.19, 524.98, 39.48, 514.91 Q 39.28, 504.83, 39.18, 494.75\
            Q 39.13, 484.67, 39.35, 474.59 Q 38.52, 464.52, 38.56, 454.44 Q 38.79, 444.36, 38.81, 434.28 Q 38.75, 424.20, 39.09, 414.12\
            Q 39.75, 404.05, 39.26, 393.97 Q 40.12, 383.89, 39.96, 373.81 Q 40.16, 363.73, 39.82, 353.66 Q 38.56, 343.58, 38.19, 333.50\
            Q 39.26, 323.42, 39.57, 313.34 Q 38.32, 303.27, 39.85, 293.19 Q 39.16, 283.11, 39.40, 273.03 Q 39.39, 262.95, 39.32, 252.88\
            Q 39.40, 242.80, 39.53, 232.72 Q 39.86, 222.64, 39.48, 212.56 Q 39.52, 202.48, 39.21, 192.41 Q 38.97, 182.33, 39.55, 172.25\
            Q 40.31, 162.17, 40.13, 152.09 Q 39.97, 142.02, 39.47, 131.94 Q 38.71, 121.86, 39.77, 111.78 Q 39.23, 101.70, 38.88, 91.62\
            Q 38.51, 81.55, 38.83, 71.47 Q 39.17, 61.39, 39.15, 51.31 Q 38.56, 41.23, 38.45, 31.16 Q 40.00, 21.08, 40.00, 11.00" style="\
            fill:white;"/>\
         </svg:svg>\
      </div>\
   </div>\
</div>');