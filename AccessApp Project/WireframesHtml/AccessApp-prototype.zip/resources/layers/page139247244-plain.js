rabbit.data.layerStore.addLayerFromHtml('<div xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:sketchedHelper="java:it.rapidrabb.editor.stencils.helpers.SketchedHelper" xmlns:fn="http://www.w3.org/2005/xpath-functions">\
   <div id="result">\
      <div xmlns:xs="http://www.w3.org/2001/XMLSchema" xmlns="http://www.w3.org/1999/xhtml" id="__containerId__page139247244-layer" class="layer" name="__containerId__pageLayer" data-layer-id="page139247244" data-layer-type="pageLayer" style="position:absolute;left:0px;top:0px;">\
         <div id="__containerId__-page139247244-layer-615435775" style="position: absolute; left: 20px; top: 65px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="615435775" data-review-reference-id="615435775">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-2001331945" style="position: absolute; left: 15px; top: 15px; width: 126px; height: 28px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="2001331945" data-review-reference-id="2001331945">\
            <div class="stencil-wrapper" style="width: 126px; height: 28px">\
               <div title="" style="width:131px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span style="font-size: 24px;">AccessApp</span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-901301961" style="position: absolute; left: 305px; top: 15px; width: 32px; height: 32px" data-interactive-element-type="fonticon.icon" class="icon stencil mobile-interaction-potential-trigger " data-stencil-id="901301961" data-review-reference-id="901301961">\
            <div class="stencil-wrapper" style="width: 32px; height: 32px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" style="width:32px;height:32px;" title="">\
                  <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" class="fill-black">\
                     <svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol xmlns:a0="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" id="icon-glyph-2609" preserveAspectRatio="xMidYMid meet">\
<title>glyph-2609</title>\
<path class="path1" d="M114.842 514.259v-66.246h132.731q-2.304 0-2.304 33.123t2.304 33.124h-132.731zM206.822 737.621l94.046-94.286q20.493 26.769 48.93 48.93l-94.286 94.046zM206.822 224.652l48.691-48.691 94.286 94.046q-27.404 21.526-48.93 48.93zM350.516 481.138q0-43.369 21.844-80.622t59.017-59.017 80.622-21.844 80.623 21.844 59.017 59.017 21.844 80.622-21.844 80.622-59.017 59.017-80.623 21.844-80.622-21.843-59.017-59.017-21.844-80.622zM478.876 878.295v-132.731q0 2.304 33.124 2.304t33.124-2.304v132.73h-66.246zM478.876 216.71v-132.731h66.246v132.731q0-2.304-33.124-2.304t-33.124 2.304zM674.201 692.266q28.436-22.161 48.93-48.93l94.046 94.286-48.691 48.691zM674.201 270.008l94.286-94.046 48.691 48.691-94.046 94.286q-21.446-27.482-48.93-48.93zM776.429 514.259q2.304 0 2.304-33.124t-2.304-33.123h132.731v66.246h-132.731z"/>\
</symbol></defs></svg>\
                     <!--load fonticon glyph-2609-->\
                     <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#icon-glyph-2609"></use>\
                  </svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-714511095" style="position: absolute; left: 20px; top: 45px; width: 94px; height: 32px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="714511095" data-review-reference-id="714511095">\
            <div class="stencil-wrapper" style="width: 94px; height: 32px">\
               <div title=""><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p class="none" style="font-size: 14px;"><span style="color: #658cd9;">Mapa de Ruta<br /><br /></span></p></span></span></div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-iphoneButton125074550" style="position: absolute; left: 140px; top: 585px; width: 69px; height: 30px" data-interactive-element-type="default.iphoneButton" class="iphoneButton pidoco-clickable-element stencil mobile-interaction-potential-trigger " data-stencil-id="iphoneButton125074550" data-review-reference-id="iphoneButton125074550">\
            <div class="stencil-wrapper" style="width: 69px; height: 30px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="" style="height: 30px;width:69px;">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" overflow="hidden" width="69" height="30" viewBox="0 0 69 30">\
                     <svg:a>\
                        <svg:path fill-rule="evenodd" clip-rule="evenodd" fill="#808080" stroke="#666666" d="M13,29.5 l-0.5,-0.5 -1,0 -1,-1 -1.5,-1.5 -8.5,-11 7.5,-11 2,-2.5 1.5,-1 0.5,-0.5 51,0 1.5,0.5 1.5,1 1,1.5 0.5,1.5 0,20 -0.5,1.5 -1,1.5 -1.5,1 -1.5,0.5 z"></svg:path>\
                        <svg:text x="37.5" y="15" dy="0.3em" fill="#FFFFFF" style="font-size:1em;stroke-width:0pt;" font-family="\'HelveticaNeue-Bold\'" text-anchor="middle" xml:space="preserve">Regresar</svg:text>\
                     </svg:a>\
                  </svg:svg>\
               </div>\
            </div>\
            <div class="interactive-stencil-highlighter" style="width: 69px; height: 30px"></div><script xmlns:json="http://json.org/" type="text/javascript">\
			$(document).ready(function(){\
				rabbit.interaction.manager.registerInteraction(\'__containerId__-page139247244-layer-iphoneButton125074550\', \'interaction405245487\', {"button":"left","id":"action481192132","numberOfFinger":"1","type":"click"},  \
					[\
						{"delay":"0","id":"reaction221806363","options":"reloadOnly","target":"page950411400","transition":"none","type":"showPage"}\
					]\
				);\
			});\
		</script></div>\
         <div id="__containerId__-page139247244-layer-1642812128" style="position: absolute; left: 15px; top: 565px; width: 321px; height: 4px" data-interactive-element-type="static.line" class="line stencil mobile-interaction-potential-trigger " data-stencil-id="1642812128" data-review-reference-id="1642812128">\
            <div class="stencil-wrapper" style="width: 321px; height: 4px">\
               <div title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" style="position: absolute; left: 0px; top: 0px; height: 4px;width:321px;" viewBox="0 0 321 4" width="321" height="4">\
                     <svg:path d="M 0,2 L 321,2" marker-start="" marker-end="" style="fill:none; stroke-width:2px;stroke:black;"></svg:path>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-image343018226" style="position: absolute; left: 15px; top: 165px; width: 329px; height: 268px" data-interactive-element-type="default.image" class="image stencil mobile-interaction-potential-trigger " data-stencil-id="image343018226" data-review-reference-id="image343018226">\
            <div class="stencil-wrapper" style="width: 329px; height: 268px">\
               <div xmlns:pidoco="http://www.pidoco.com/util" title="">\
                  <svg:svg xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:svg="http://www.w3.org/2000/svg" class="image-cropper" style="height: 268px;width:329px;" width="329" height="268" viewBox="0 0 329 268">\
                     <svg:g width="329" height="268">\
                        <svg:svg x="0" y="0" width="329" height="268">\
                           <svg:image width="329" height="268" xlink:href="../repoimages/687851.png" preserveAspectRatio="none" transform="scale(1,1) translate(-0,-0)  "></svg:image>\
                        </svg:svg>\
                     </svg:g>\
                  </svg:svg>\
               </div>\
            </div>\
         </div>\
         <div id="__containerId__-page139247244-layer-1740068988" style="position: absolute; left: 25px; top: 110px; width: 141px; height: 17px" data-interactive-element-type="default.text2" class="text2 stencil mobile-interaction-potential-trigger " data-stencil-id="1740068988" data-review-reference-id="1740068988">\
            <div class="stencil-wrapper" style="width: 141px; height: 17px">\
               <div title="" style="width:146px"><span class="default-text2-container-wrapper" title=""><span class="default-text2-container" data-child-type="default.text2"><p style="font-size: 14px;"><span class="bold" style="color: #658cd9;">Información de Ruta</span></p></span></span></div>\
            </div>\
         </div>\
      </div>\
   </div>\
   <div id="styles">\
      <style type="text/css">\
         	\
         		body[data-current-page-id="page139247244"] .border-wrapper, body[data-current-page-id="page139247244"] .simulation-container{\
         			width:360px;\
         		}\
         		\
         		body.has-frame[data-current-page-id="page139247244"] .border-wrapper, body.has-frame[data-current-page-id="page139247244"]\
         .simulation-container{\
         			height:640px;\
         		}\
         		\
         		body[data-current-page-id="page139247244"] .svg-border-360-640{\
         			display: block !important;\
         		}\
         		\
         		body[data-current-page-id="page139247244"] .border-wrapper .border-div{\
         			width:360px;\
         			height:640px;\
         		}\
         	\
      </style>\
   </div>\
   <div id="json">\
      		{\
      			"id": "page139247244",\
      			"name": "6. AccessApp Mostrar Rutas",\
      			"layers": {\
      				\
      			},\
      			"image":"",\
      			"width":360,\
      			"height":640,\
      			"parentFolder": "",\
      			"frame": "smartphone",\
      			"frameOrientation": "portrait"\
      		}\
      	\
   </div>\
</div>');